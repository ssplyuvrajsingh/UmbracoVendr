﻿
public interface IDummyDataSurfaceServices
{
    void CreateDummyData();
}