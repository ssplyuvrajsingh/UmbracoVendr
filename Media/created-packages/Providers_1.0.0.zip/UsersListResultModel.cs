﻿public class UsersListResultModel
{
    public int Id { get; set; }

    public string Name { get; set; }

    public string Email { get; set; }

    public string ProviderType { get; set; }

    public string Key { get; set; }

    public string FileType { get; set; }

    public string FileName { get; set; }

    public string FileUrl { get; set; }
    public string MediaUDI { get; set; }
}