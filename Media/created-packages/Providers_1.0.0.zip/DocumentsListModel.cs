﻿public class DocumentsListModel
{
    public int DocumentPageId { get; set; }

    public string DocumentType { get; set; }

    public string DocumentRoutePath { get; set; }
}