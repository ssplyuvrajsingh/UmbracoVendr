﻿using System;

namespace FinCMS.App_Code.Models.Dtos
{
    public class RemoveFromCartDto
    {
        public Guid OrderLineId { get; set; }
    }
}